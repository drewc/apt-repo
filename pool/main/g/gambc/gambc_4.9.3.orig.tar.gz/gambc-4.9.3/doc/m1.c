/* File: "m1.c" */
int power_of_2 (int x) { return 1<<x; }
