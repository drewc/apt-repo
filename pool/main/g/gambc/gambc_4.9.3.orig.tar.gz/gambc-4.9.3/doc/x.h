int x_initialize (char *display_name);
char *x_display_name (void);
void x_bell (int);
