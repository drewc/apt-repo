//
//  ITView.h
//
//  Created by Marc Feeley
//  Copyright 2014 Université de Montréal. All rights reserved.
//

#import <UIKit/UITextView.h>

//-----------------------------------------------------------------------------

@interface ITView : UITextView
{
}

@end

//-----------------------------------------------------------------------------
