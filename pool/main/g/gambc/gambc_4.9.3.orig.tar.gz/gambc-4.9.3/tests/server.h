/* File: "server.h", Time-stamp: <2007-04-04 11:40:37 feeley> */

/*
 * The only declaration in "server.scm" is the function "eval_string".
 */

extern char *eval_string (char *);
