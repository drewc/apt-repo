# Build Tool

The `:std/make` library provides support for building source Gerbil projects.
See also the [guide](/guide/build.md).

::: tip usage
(import :std/make)
:::

## Overview

Please write me!

## Interface

### make
::: tip usage
```
(make ...)
```
:::

Please document me!

### make-depgraph
::: tip usage
```
(make-depgraph ...)
```
:::

Please document me!

### make-depgraph/spec
::: tip usage
```
(make-depgraph/spec ...)
```
:::

Please document me!

### shell-config
::: tip usage
```
(shell-config ...)
```
:::

Please document me!

### env-cppflags
::: tip usage
```
(env-cppflags ...)
```
:::

Please document me!

### env-ldflags
::: tip usage
```
(env-ldflags ...)
```
:::

Please document me!

### include-gambit-sharp
::: tip usage
```
(include-gambit-sharp ...)
```
:::

Please document me!

### pkg-config
::: tip usage
```
(pkg-config ...)
```
:::

Please document me!

### pkg-config-libs
::: tip usage
```
(pkg-config-libs ...)
```
:::

Please document me!

### pkg-config-cflags
::: tip usage
```
(pkg-config-cflags ...)
```
:::

Please document me!

### ldflags
::: tip usage
```
(ldflags ...)
```
:::

Please document me!

### cppflags
::: tip usage
```
(cppflags ...)
```
:::

Please document me!


## Standard Package Build Script
::: tip usage
(import :std/build-script)
:::

### defbuild-script
::: tip usage
```
(defbuild-script ...)
```
:::

Please document me!
