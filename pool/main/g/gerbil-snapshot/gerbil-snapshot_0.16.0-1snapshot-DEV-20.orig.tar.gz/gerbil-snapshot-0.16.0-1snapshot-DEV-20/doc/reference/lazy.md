# Primitives for Lazy Evaluation

Primitives for iterative lazy algorithms, as specified in R7RS; see also
[SRFI-45](https://srfi.schemers.org/srfi-45/)

::: tip usage
(import :std/lazy)
:::

### lazy
::: tip usage
```
(lazy ...)
```
:::

Please document me!

### delay
::: tip usage
```
(delay ...)
```
:::

Please document me!

### force
::: tip usage
```
(force ...)
```
:::

Please document me!

### lazy?
::: tip usage
```
(lazy? ...)
```
:::

Please document me!

### eager
::: tip usage
```
(eager ...)
```
:::

Please document me!
