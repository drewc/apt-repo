# Syntax Parameters

::: tip usage
(import :std/stxparam)
:::

## Macros

### defsyntax-parameter
::: tip usage
```
(defsyntax-parameter ...)
```
:::

Please document me!

### syntax-parameterize
::: tip usage
```
(syntax-parameterize ...)
```
:::

Please document me!

## Syntax Bindings

For syntax bindings [phi=+1] for use in macros.

### syntax-parameter
```
(defclass syntax-parameter (key default))
```

Please document me!

### syntax-parameter-value
::: tip usage
```
(syntax-parameter-value ...)
```
:::

Please document me!

### syntax-parameter-e
::: tip usage
```
(syntax-parameter-e ...)
```
:::

Please document me!
