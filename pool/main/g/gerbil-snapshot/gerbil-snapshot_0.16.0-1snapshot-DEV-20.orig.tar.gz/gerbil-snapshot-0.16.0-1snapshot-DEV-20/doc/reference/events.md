# Events

Event-driven programming facilities.

::: tip usage
(import :std/event)
:::

## Overview

Please write me!

## Synchronization Primitives

### wait
::: tip usage
```
(wait ...)
```
:::

Please document me!

### select
::: tip usage
```
(select ...)
```
:::

Please document me!

### sync
::: tip usage
```
(sync ...)
```
:::

Please document me!


## Event Objects

### wrap-evt
::: tip usage
```
(wrap-evt ...)
```
:::

Please document me!

### handle-evt
::: tip usage
```
(handle-evt ...)
```
:::

Please document me!

### choice-evt
::: tip usage
```
(choice-evt ...)
```
:::

Please document me!

### never-evt
::: tip usage
```
(never-evt ...)
```
:::

Please document me!

### always-evt
::: tip usage
```
(always-evt ...)
```
:::

Please document me!

### sync-object?
::: tip usage
```
(sync-object? ...)
```
:::

Please document me!

### make-event
::: tip usage
```
(make-event ...)
```
:::

Please document me!

### event?
::: tip usage
```
(event? ...)
```
:::

Please document me!

### event-e
::: tip usage
```
(event-e ...)
```
:::

Please document me!

### event-e-set!
::: tip usage
```
(event-e-set! ...)
```
:::

Please document me!

## Macros

### !
::: tip usage
```
(! ...)
```
:::

Please document me!

### !*
::: tip usage
```
(!* ...)
```
:::

Please document me!


## Example

Please write me!
