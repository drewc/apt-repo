# XML

::: tip usage
(import :std/xml)
:::

## Overview

Please write me!

## Parsing

### read-xml
::: tip usage
```
(read-xml ...)
```
:::

Please document me!

### parse-xml [libxml]
::: tip usage
```
(parse-xml ...)
```
:::

Please document me!

### parse-html [libxml]
::: tip usage
```
(parse-html ...)
```
:::

Please document me!


## SXML Queries

### sxpath
::: tip usage
```
(sxpath ...)
```
:::

Please document me!

### sxml-select
::: tip usage
```
(sxml-select ...)
```
:::

Please document me!

### sxml-attributes
::: tip usage
```
(sxml-attributes ...)
```
:::

Please document me!

### sxml-e
::: tip usage
```
(sxml-e ...)
```
:::

Please document me!

### sxml-find
::: tip usage
```
(sxml-find ...)
```
:::

Please document me!

### sxml-select*
::: tip usage
```
(sxml-select* ...)
```
:::

Please document me!

### sxml-attribute-e
::: tip usage
```
(sxml-attribute-e ...)
```
:::

Please document me!

### sxml-attribute-getq
::: tip usage
```
(sxml-attribute-getq ...)
```
:::

Please document me!

### sxml-class?
::: tip usage
```
(sxml-class? ...)
```
:::

Please document me!

### sxml-find*
::: tip usage
```
(sxml-find* ...)
```
:::

Please document me!

### sxml-e?
::: tip usage
```
(sxml-e? ...)
```
:::

Please document me!

### sxml-id?
::: tip usage
```
(sxml-id? ...)
```
:::

Please document me!

### sxml-children
::: tip usage
```
(sxml-children ...)
```
:::

Please document me!

### sxml-find/context
::: tip usage
```
(sxml-find/context ...)
```
:::

Please document me!


## Printing


### write-xml
::: tip usage
```
(write-xml ...)
```
:::

Please document me!

### write-html
::: tip usage
```
(write-html ...)
```
:::

Please document me!

### print-sxml-&gt;html
::: tip usage
```
(print-sxml->html ...)
```
:::

Please document me!

### print-sxml-&gt;html*
::: tip usage
```
(print-sxml->html* ...)
```
:::

Please document me!

### print-sxml-&gt;html-fast
::: tip usage
```
(print-sxml->html-fast ...)
```
:::

Please document me!

### print-sxml-&gt;xhtml
::: tip usage
```
(print-sxml->xhtml ...)
```
:::

Please document me!

### print-sxml-&gt;xhtml*
::: tip usage
```
(print-sxml->xhtml* ...)
```
:::

Please document me!

### print-sxml-&gt;xhtml-fast
::: tip usage
```
(print-sxml->xhtml-fast ...)
```
:::

Please document me!

### print-sxml-&gt;xml
::: tip usage
```
(print-sxml->xml ...)
```
:::

Please document me!

### print-sxml-&gt;xml*
::: tip usage
```
(print-sxml->xml* ...)
```
:::

Please document me!

### print-sxml-&gt;xml-fast
::: tip usage
```
(print-sxml->xml-fast ...)
```
:::

Please document me!

### pretty-print-sxml-&gt;xml-file
::: tip usage
```
(pretty-print-sxml->xml-file ...)
```
:::

Please document me!

### pretty-print-sxml-&gt;xhtml-file
::: tip usage
```
(pretty-print-sxml->xhtml-file ...)
```
:::

Please document me!

### sxml-&gt;html-string-fragment
::: tip usage
```
(sxml->html-string-fragment ...)
```
:::

Please document me!

### sxml-&gt;xhtml-string
::: tip usage
```
(sxml->xhtml-string ...)
```
:::

Please document me!
